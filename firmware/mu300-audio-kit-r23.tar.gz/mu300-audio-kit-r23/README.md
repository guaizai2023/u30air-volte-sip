# 可能会用到的固件与安装包（解压使用）

这套东西是 U30 Air 从"哑巴设备"变成"能出声"的**全部关键材料**，
也是在折腾过程中最难找、最容易卡住的几块。打包留档，换机、重刷、换内核时直接解压取用。

> 解压：`tar xzf mu300-audio-kit-r23.tar.gz`
> 安装前请先读完本文件，尤其是最后的「硬约束」。

---

## 一、目录内容

```
mu300-audio-kit-r23/
├── agdsp.bin                              ← ★ AUDCP 数字信号处理器固件（没它全程无声）
├── luci-app-airsim-0.1.0-r23.apk          ← ★ 社区音频栈（含音频内核模块 + 工具 + LuCI 页）
├── airsim-install-r23.sh                  ← 官方安装脚本（已逐行审查，可直接用）
└── audio_params/                          ← 音频参数（参考用，一般不用手动装）
    ├── audio_config.xml                   vendor 侧音频通路配置（含 VBC DAC0/DAC1 DSP MDG 控件名）
    ├── odm_audio_params/
    │   ├── audio_structure.xml            2.29 MB 音频结构参数
    │   ├── dsp_vbc.xml                    690 KB  VBC 参数
    │   ├── audio_process.xml              629 KB  处理链参数
    │   ├── dsp_smartamp.xml               835 KB  智能功放参数
    │   └── audioparam_config.xml          12 KB   索引
    └── odm_firmware/
        └── audio_structure                48,934 B，magic `audio_profile`（e5-linux 需要的 5 个文件之一）
```

---

## 二、每个文件是干什么的

| 文件 | 作用 | 缺了会怎样 |
|---|---|---|
| `agdsp.bin` | 展锐 AUDCP 固件，DSP 的"操作系统"。放到 `/lib/firmware/agdsp.bin` | 声卡注册失败或注册了但**一点声音都没有** |
| `luci-app-airsim-*.apk` | 社区重建的音频栈：音频内核模块（匹配 5.4 内核）+ `mu300-audio-dsp` / `mu300-voice` 等工具 + LuCI 页面 | 没有 `/dev/snd`，没有 `mu300-voice` 场景命令 |
| `airsim-install-r23.sh` | 官方安装脚本：校验环境 → 验签 → `apk add` → 跑 `audio-setup --status` | 手动装容易漏依赖、装错版本 |
| `audio_params/*` | 从本机原厂 Android `odm` 分区导出的调音参数 | 一般不影响出声；换内核/调音色时作对照 |

**注意**：`audio_params` 是从本机 Android 侧只读导出的，**不是**必须安装的文件。
音频栈自己带了一套能用的参数。留着是为了以后换内核或调音时有个基准。

---

## 三、怎么用（推荐顺序）

设备必须是 OpenWrt、`aarch64`、`apk-tools 3.x`，并且**内核为 `5.4.254-gb50db5b6224c`**。

```sh
# 0. 把包传上去（本机与设备同网段）
scp mu300-audio-kit-r23.tar.gz root@192.168.77.1:/tmp/
ssh root@192.168.77.1

# 1. 解压
cd /tmp && tar xzf mu300-audio-kit-r23.tar.gz && cd mu300-audio-kit-r23

# 2. 先干跑检查（不改任何东西）
sh airsim-install-r23.sh --check

# 3. 正式安装（会验签 APK，装音频模块与工具）
sh airsim-install-r23.sh --install

# 4. 确认固件在位（安装包通常会自动放，若没有则手动补）
ls -l /lib/firmware/agdsp.bin
#   预期 6,291,456 字节；不对就把本包里的 agdsp.bin 拷过去：
#   cp agdsp.bin /lib/firmware/agdsp.bin

# 5. 确认音频栈状态
mu300-audio-dsp status
cat /proc/asound/cards          # 应出现 sprdphone-sc2730
```

装完之后，桥接程序依赖的两个节点应当是：

```
hw:1,53   FE_ST_VOICE_PCM_P   16 kHz 注入（我 → 对方）
hw:1,16   FE_ST_DUMP          48 kHz 采集（对方 → 我）
```

---

## 四、校验值

安装前请核对，避免下到半截或被人改过的文件。

| 文件 | 大小 | sha256 |
|---|---|---|
| `agdsp.bin` | 6,291,456 B | `378ceea78dbf013e10625e71efd6fab487d727e371884ae8daf078da2828b937` |
| `luci-app-airsim-0.1.0-r23.apk` | 8.8 MB | `1c4edc03b5eaf0b193e26209f0342a070b104bc57e0c35a862bce47f21600fad` |
| `airsim-install-r23.sh` | 5.0 KB | `ace1cb17c39345020da4d487ac9c0e9997636fa438453ba5aadb12b5351bdb54` |
| `audio_params/odm_firmware/audio_structure` | 48,934 B | `21b5684364d295ddf90521c625d008b2aef8753f929bda888d911e31369f7c3c` |

```sh
sha256sum *
```

`agdsp.bin` 的这个哈希与上游 `mu300-audio-dsp` 脚本第 459 行硬编码的 `FW_URL_SHA256` **逐字符一致**，
也和 `airsim-f50-openwrt` 踩坑记录里的 6,291,456 字节互相印证。头部标识：`SharkL5_AUDCP_2022Y_VER_2548`。

---

## 五、来源

| 材料 | 来源 |
|---|---|
| `agdsp.bin` | `dikeckaan/mu300-audio-firmware` releases v1.0 |
| `luci-app-airsim-0.1.0-r23.apk` + 安装脚本 | `kai-wu-cortex/airsim-mu300` releases v0.1.0-r23 |
| `audio_params/*` | 本机原厂 Android `odm_a` 分区只读导出（`super` → LP metadata → erofs 解包） |

安装脚本审查结论：只从固定地址下载 3 个文件、用硬编码公钥指纹验签、`apk add --no-upgrade` 安装；
**不写分区、不改 boot、不改 IMEI/NV、不向外部回传数据、不启停基带**，脚本末尾声明未发起通话或短信。

---

## 六、硬约束（重要）

1. **语音只在 `5.4.254-gb50db5b6224c` 内核下可用。**
   社区两套内核实测对照过，其他版本（含 6.18 / 7.3）模块加载得上，但语音通路不通。
   装之前先 `uname -r` 确认。
2. **安装时不能有进行中的通话 / 媒体 / 短信**，脚本会直接拒绝。
3. 本机原厂 Android 镜像**不含** AUDCP 固件（全盘搜 `AUDCP` 零命中），
   所以 `agdsp.bin` 只能从社区取，不能从自己机器里抠。
4. 装完若 DSP 睡死唤不醒，先 `mu300-audio-dsp start`，仍不行就重启再试 —— 不要反复 `apk del/add`。

---

## 七、免责

`agdsp.bin` 与 APK 内的厂商二进制版权归原厂/相应权利人所有，此处仅作**个人设备维修与自用**留档，
不构成任何再分发授权。请勿用于商业用途。刷机有风险，操作前自行备份，后果自负。
